import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

const STORAGE_KEY = 'Agro_wishlist';
const WishlistContext = createContext();

const normalizeWishlistItems = (items) => {
  if (!Array.isArray(items)) {
    return [];
  }

  const seen = new Set();

  return items.filter((item) => {
    if (!item?.id || seen.has(item.id)) {
      return false;
    }

    seen.add(item.id);
    return true;
  });
};

const readStoredWishlist = () => {
  try {
    return normalizeWishlistItems(JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'));
  } catch (error) {
    console.error('Error parsing wishlist data', error);
    return [];
  }
};

export const useWishlist = () => useContext(WishlistContext);

export const WishlistProvider = ({ children }) => {
  const [wishlistItems, setWishlistItems] = useState(readStoredWishlist);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(wishlistItems));
    } catch (error) {
      console.error('Error saving wishlist data', error);
    }
  }, [wishlistItems]);

  const isInWishlist = useCallback(
    (productId) => wishlistItems.some((item) => item.id === productId),
    [wishlistItems]
  );

  const addToWishlist = useCallback((product) => {
    if (!product?.id) {
      return false;
    }

    setWishlistItems((items) => {
      if (items.some((item) => item.id === product.id)) {
        return items;
      }

      return [...items, product];
    });

    return true;
  }, []);

  const removeFromWishlist = useCallback((productId) => {
    setWishlistItems((items) => items.filter((item) => item.id !== productId));
  }, []);

  const toggleWishlist = useCallback(
    (product) => {
      if (!product?.id) {
        return 'error';
      }

      if (isInWishlist(product.id)) {
        removeFromWishlist(product.id);
        return 'removed';
      }

      addToWishlist(product);
      return 'added';
    },
    [addToWishlist, isInWishlist, removeFromWishlist]
  );

  const value = useMemo(
    () => ({
      wishlistItems,
      wishlistCount: wishlistItems.length,
      isInWishlist,
      addToWishlist,
      removeFromWishlist,
      toggleWishlist,
    }),
    [addToWishlist, isInWishlist, removeFromWishlist, toggleWishlist, wishlistItems]
  );

  return <WishlistContext.Provider value={value}>{children}</WishlistContext.Provider>;
};
