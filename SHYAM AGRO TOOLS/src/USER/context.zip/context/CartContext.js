import React, { createContext, useState, useContext, useEffect } from 'react';
import { useToast } from './ToastContext';
import { useLanguage } from './LanguageContext';

const CartContext = createContext();

export const useCart = () => useContext(CartContext);

export const CartProvider = ({ children }) => {
  const { showToast } = useToast();
  const { t } = useLanguage();
  const [cartItems, setCartItems] = useState(() => {
    try {
      const localData = localStorage.getItem('Agro_cart');
      return localData ? JSON.parse(localData) : [];
    } catch (error) {
      console.error("Error parsing cart data", error);
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem('Agro_cart', JSON.stringify(cartItems));
  }, [cartItems]);

  const addToCart = (product) => {
    if (!product?.id) {
      showToast(t('unableAddProductToCart'), 'error');
      return;
    }

    setCartItems(prevItems => {
      const existingItem = prevItems.find(item => item.id === product.id);
      if (existingItem) {
        return prevItems.map(item =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prevItems, { ...product, quantity: 1 }];
    });

    showToast(t('addedToCartStandalone'));
  };

  const removeFromCart = (productId) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId, delta) => {
    setCartItems(prevItems =>
      prevItems.reduce((updatedItems, item) => {
        if (item.id !== productId) {
          return [...updatedItems, item];
        }

        const newQty = item.quantity + delta;
        if (newQty < 1) {
          return updatedItems;
        }

        return [...updatedItems, { ...item, quantity: newQty }];
      }, [])
    );
  };

  const clearCart = () => setCartItems([]);

  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const cartSubtotal = cartItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);

  return (
    <CartContext.Provider value={{ 
      cartItems, 
      addToCart, 
      removeFromCart, 
      updateQuantity, 
      clearCart,
      cartCount,
      cartSubtotal
    }}>
      {children}
    </CartContext.Provider>
  );
};
