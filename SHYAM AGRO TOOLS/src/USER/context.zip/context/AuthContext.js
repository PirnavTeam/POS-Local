import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';

const STORAGE_KEYS = {
  user: 'user',
  authUser: 'authUser',
  token: 'token',
  authToken: 'authToken',
  refreshToken: 'refreshToken',
};

const AuthContext = createContext(null);

const getResponseValue = (source, keys) => {
  for (const key of keys) {
    if (source?.[key] !== undefined && source?.[key] !== null) return source[key];
  }
  return undefined;
};

export const normalizeAuthResponse = (data, fallback = {}) => {
  const userData = data?.user || data?.data?.user || data?.data || data || {};
  const token = getResponseValue(data, ['token', 'accessToken', 'jwtToken', 'authToken'])
    || getResponseValue(userData, ['token', 'accessToken', 'jwtToken', 'authToken'])
    || '';
  const refreshToken = getResponseValue(data, ['refreshToken'])
    || getResponseValue(userData, ['refreshToken'])
    || '';

  return {
    phone: getResponseValue(userData, ['phone', 'mobileNumber', 'MobileNumber']) || fallback.phone || '',
    name: getResponseValue(userData, ['name', 'fullName', 'FullName']) || fallback.name || 'User',
    email: getResponseValue(userData, ['email', 'Email']) || fallback.email || '',
    token,
    refreshToken,
    wallet: getResponseValue(userData, ['wallet', 'walletBalance']) || 0,
    id: getResponseValue(userData, ['id', 'userId', 'customerId']) || fallback.phone || '',
    loggedIn: true,
  };
};

export const isSuccessfulAuthResponse = (data) => {
  if (!data) return false;
  if (data.success === false) return false;
  return Boolean(data.success === true || data.token || data.accessToken || data.authToken || data.user || data.data);
};

export const readStoredUser = () => {
  const candidates = [
    [localStorage, STORAGE_KEYS.user],
    [localStorage, STORAGE_KEYS.authUser],
    [sessionStorage, STORAGE_KEYS.user],
    [sessionStorage, STORAGE_KEYS.authUser],
  ];

  for (const [storage, key] of candidates) {
    const savedUser = storage.getItem(key);
    if (!savedUser) continue;
    try {
      return JSON.parse(savedUser);
    } catch (error) {
      storage.removeItem(key);
    }
  }

  return null;
};

const saveAuthSession = (user) => {
  Object.values(STORAGE_KEYS).forEach((key) => {
    localStorage.removeItem(key);
    sessionStorage.removeItem(key);
  });
  localStorage.setItem(STORAGE_KEYS.user, JSON.stringify(user));
  localStorage.setItem(STORAGE_KEYS.authUser, JSON.stringify(user));
  if (user.token) {
    localStorage.setItem(STORAGE_KEYS.token, user.token);
    localStorage.setItem(STORAGE_KEYS.authToken, user.token);
  }
  if (user.refreshToken) {
    localStorage.setItem(STORAGE_KEYS.refreshToken, user.refreshToken);
  }
};

const clearAuthSession = () => {
  Object.values(STORAGE_KEYS).forEach((key) => {
    localStorage.removeItem(key);
    sessionStorage.removeItem(key);
  });
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => readStoredUser());

  useEffect(() => {
    const syncUser = () => setUser(readStoredUser());
    window.addEventListener('storage', syncUser);
    window.addEventListener('auth:user-updated', syncUser);
    return () => {
      window.removeEventListener('storage', syncUser);
      window.removeEventListener('auth:user-updated', syncUser);
    };
  }, []);

  const login = useCallback((nextUser) => {
    saveAuthSession(nextUser);
    setUser(nextUser);
    window.dispatchEvent(new CustomEvent('auth:user-updated', { detail: nextUser }));
  }, []);

  const logout = useCallback(() => {
    clearAuthSession();
    setUser(null);
    window.dispatchEvent(new CustomEvent('auth:user-updated', { detail: null }));
  }, []);

  const value = useMemo(() => ({
    user,
    isAuthenticated: Boolean(user?.loggedIn || user?.id || user?.phone || user?.token),
    login,
    logout,
  }), [login, logout, user]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used inside AuthProvider');
  }
  return context;
};
